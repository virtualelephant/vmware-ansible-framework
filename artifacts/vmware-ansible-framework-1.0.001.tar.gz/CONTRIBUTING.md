# Contributing - Use feature branches + MR with CI green checks. - Keep roles atomic; prefer idempotence and check-mode support. - Add docs to `docs/runbooks` for operational procedures.
