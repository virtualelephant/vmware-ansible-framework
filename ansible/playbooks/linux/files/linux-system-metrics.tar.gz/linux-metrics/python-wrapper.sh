#!/bin/bash

source /opt/metrics-collector/venv/bin/activate
exec python3 /opt/metrics-collector/metrics_collector.py